package GameYourMeme.users

class User5 extends Users{

  this.name = "User5"
  this.pointCount= 0

}
