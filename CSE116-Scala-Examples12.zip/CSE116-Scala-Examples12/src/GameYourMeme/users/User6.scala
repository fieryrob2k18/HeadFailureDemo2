package GameYourMeme.users

class User6 extends Users{

  this.name = "User6"
  this.pointCount= 0

}