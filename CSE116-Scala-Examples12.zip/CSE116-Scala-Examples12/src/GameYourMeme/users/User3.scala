package GameYourMeme.users

class User3 extends Users{

  this.name = "User3"
  this.pointCount= 0

}