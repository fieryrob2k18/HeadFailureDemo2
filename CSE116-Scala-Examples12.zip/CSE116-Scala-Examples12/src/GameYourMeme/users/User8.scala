package GameYourMeme.users

class User8 extends Users{

  this.name = "User8"
  this.pointCount= 0

}
