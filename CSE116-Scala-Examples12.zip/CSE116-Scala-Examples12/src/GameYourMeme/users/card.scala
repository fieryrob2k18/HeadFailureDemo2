package GameYourMeme.users


class Card(val caption: String, val owner: Player) {
}

