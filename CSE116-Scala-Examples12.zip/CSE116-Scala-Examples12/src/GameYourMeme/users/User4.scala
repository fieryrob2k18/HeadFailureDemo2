package GameYourMeme.users

class User4 extends Users{

  this.name = "User4"
  this.pointCount= 0

}
