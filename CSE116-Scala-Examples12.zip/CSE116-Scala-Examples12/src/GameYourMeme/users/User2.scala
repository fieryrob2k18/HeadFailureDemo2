package GameYourMeme.users

class User2 extends Users {

  this.name = "User2"
  this.pointCount= 0

}