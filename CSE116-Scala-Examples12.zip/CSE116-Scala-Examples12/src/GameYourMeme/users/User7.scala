package GameYourMeme.users

class User7 extends Users{

  this.name = "User7"
  this.pointCount= 0

}